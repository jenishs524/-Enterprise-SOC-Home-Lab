# SOAR Module Initializer
