import os
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

app = FastAPI(title="Enterprise SOC Web Portal")

# Static assets if exists
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/", response_class=HTMLResponse)
def index():
    return """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise SOC Platform Command Center</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
    <style>
        :root {
            --bg-primary: #0b0f19;
            --bg-card: #111827;
            --bg-header: #0d1322;
            --border-color: #1f293d;
            --text-main: #e2e8f0;
            --text-muted: #94a3b8;
            --accent-blue: #3b82f6;
            --accent-cyan: #06b6d4;
            --sev-critical: #ef4444;
            --sev-high: #f97316;
            --sev-medium: #eab308;
            --sev-low: #3b82f6;
            --status-online: #10b981;
            --status-offline: #64748b;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-primary); color: var(--text-main); display: flex; height: 100vh; overflow: hidden; }

        /* Sidebar Navigation */
        .sidebar {
            width: 240px;
            background: var(--bg-header);
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
        }
        .brand {
            padding: 20px;
            font-size: 1.1rem;
            font-weight: 700;
            color: #fff;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid var(--border-color);
        }
        .brand-badge {
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-cyan));
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .nav-list { list-style: none; padding: 15px 10px; flex: 1; overflow-y: auto; }
        .nav-item {
            padding: 10px 14px;
            border-radius: 6px;
            margin-bottom: 4px;
            color: var(--text-muted);
            cursor: pointer;
            font-size: 0.88rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.2s ease;
        }
        .nav-item:hover, .nav-item.active {
            background: rgba(59, 130, 246, 0.15);
            color: #fff;
        }
        .nav-item.active { border-left: 3px solid var(--accent-blue); }

        /* Main Content Workspace */
        .main-container { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
        
        .topbar {
            height: 60px;
            background: var(--bg-header);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 25px;
        }
        .topbar-title { font-size: 1.1rem; font-weight: 600; color: #fff; }
        .user-status { display: flex; align-items: center; gap: 15px; font-size: 0.85rem; }
        .badge-live {
            background: rgba(16, 185, 129, 0.2);
            color: var(--status-online);
            border: 1px solid var(--status-online);
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .content-area { flex: 1; padding: 20px; overflow-y: auto; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }

        /* Metric Cards Grid */
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 18px;
        }
        .card-title { font-size: 0.8rem; color: var(--text-muted); font-weight: 500; text-transform: uppercase; margin-bottom: 8px; }
        .card-value { font-size: 1.8rem; font-weight: 700; color: #fff; }
        .card-sub { font-size: 0.78rem; color: var(--text-muted); margin-top: 5px; }

        /* Custom Tables */
        .table-card { background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 8px; overflow: hidden; margin-bottom: 20px; }
        .table-header { padding: 15px 20px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; }
        .table-header h3 { font-size: 1rem; font-weight: 600; }
        
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 0.85rem; }
        th { background: #0f172a; padding: 12px 16px; color: var(--text-muted); font-weight: 600; border-bottom: 1px solid var(--border-color); }
        td { padding: 12px 16px; border-bottom: 1px solid var(--border-color); color: var(--text-main); }
        tr:hover { background: rgba(255, 255, 255, 0.02); }

        .badge-sev { padding: 3px 8px; border-radius: 4px; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; }
        .sev-critical { background: rgba(239, 68, 68, 0.2); color: var(--sev-critical); border: 1px solid var(--sev-critical); }
        .sev-high { background: rgba(249, 115, 22, 0.2); color: var(--sev-high); border: 1px solid var(--sev-high); }
        .sev-medium { background: rgba(234, 179, 8, 0.2); color: var(--sev-medium); border: 1px solid var(--sev-medium); }
        .sev-low { background: rgba(59, 130, 246, 0.2); color: var(--sev-low); border: 1px solid var(--sev-low); }

        /* Controls & Inputs */
        input, select, button {
            background: #0f172a;
            border: 1px solid var(--border-color);
            color: #fff;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 0.85rem;
            outline: none;
        }
        button { background: var(--accent-blue); font-weight: 600; cursor: pointer; border: none; transition: background 0.2s; }
        button:hover { background: #2563eb; }

        /* Graph Network */
        #network-graph { width: 100%; height: 450px; background: #090d16; border-radius: 8px; border: 1px solid var(--border-color); }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="brand">
            🛡️ Enterprise SOC
            <span class="brand-badge">PRO v2.5</span>
        </div>
        <ul class="nav-list">
            <li class="nav-item active" onclick="switchTab('dashboard', this)">📊 Executive Overview</li>
            <li class="nav-item" onclick="switchTab('alerts', this)">🚨 Alert Stream & Triage</li>
            <li class="nav-item" onclick="switchTab('incidents', this)">🔥 Incidents & Cases</li>
            <li class="nav-item" onclick="switchTab('investigations', this)">🔍 Investigation Graph</li>
            <li class="nav-item" onclick="switchTab('hunting', this)">🏹 Threat Hunting</li>
            <li class="nav-item" onclick="switchTab('assets', this)">💻 Asset Inventory</li>
            <li class="nav-item" onclick="switchTab('mitre', this)">🧩 MITRE ATT&CK Matrix</li>
            <li class="nav-item" onclick="switchTab('health', this)">🩺 SOC Health Monitor</li>
            <li class="nav-item" onclick="switchTab('playbooks', this)">⚡ SOAR Playbooks</li>
            <li class="nav-item" onclick="switchTab('reports', this)">📑 Reports & Audit</li>
        </ul>
    </div>

    <!-- Main Workspace -->
    <div class="main-container">
        <div class="topbar">
            <div class="topbar-title" id="tab-title">Executive Command Center</div>
            <div class="user-status">
                <span class="badge-live">● REAL-TIME TELEMETRY</span>
                <span>Analyst: <strong>Admin (L2/L3)</strong></span>
            </div>
        </div>

        <div class="content-area">
            
            <!-- Dashboard Tab -->
            <div id="tab-dashboard" class="tab-content active">
                <div class="metrics-grid">
                    <div class="card">
                        <div class="card-title">Total Alerts Ingested</div>
                        <div class="card-value" id="stat-alerts">0</div>
                        <div class="card-sub">Updated live</div>
                    </div>
                    <div class="card">
                        <div class="card-title">Active Unresolved Incidents</div>
                        <div class="card-value" id="stat-incidents">0</div>
                        <div class="card-sub">Requires triage</div>
                    </div>
                    <div class="card">
                        <div class="card-title">Monitored Assets</div>
                        <div class="card-value" id="stat-assets">5</div>
                        <div class="card-sub">100% Agent Coverage</div>
                    </div>
                    <div class="card">
                        <div class="card-title">Events Normalized (EPS)</div>
                        <div class="card-value" id="stat-events">14.2</div>
                        <div class="card-sub">Continuous Syslog Stream</div>
                    </div>
                </div>

                <div class="table-card">
                    <div class="table-header">
                        <h3>Critical & High Priority Security Alerts</h3>
                        <button onclick="refreshData()">Refresh Telemetry</button>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Timestamp</th>
                                <th>Alert Title</th>
                                <th>Severity</th>
                                <th>Source IP / Host</th>
                                <th>Risk Score</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody id="dashboard-alerts-body">
                            <tr><td colspan="6">Loading SOC telemetry...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Alerts Tab -->
            <div id="tab-alerts" class="tab-content">
                <div class="table-card">
                    <div class="table-header">
                        <h3>Alert Stream Management</h3>
                        <input type="text" id="alert-search" placeholder="Search IP, Title, Rule..." onkeyup="filterAlerts()">
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Timestamp</th>
                                <th>Title</th>
                                <th>Severity</th>
                                <th>Source</th>
                                <th>MITRE ATT&CK</th>
                                <th>Risk Score</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="all-alerts-body">
                            <tr><td colspan="8">Loading alerts...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Incidents & Cases Tab -->
            <div id="tab-incidents" class="tab-content">
                <div class="table-card">
                    <div class="table-header">
                        <h3>Active Security Incidents & Cases</h3>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Incident ID</th>
                                <th>Title</th>
                                <th>Severity</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th>Category</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="incidents-body">
                            <tr><td colspan="8">Loading incidents...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Investigation Tab -->
            <div id="tab-investigations" class="tab-content">
                <div class="table-card" style="padding: 15px;">
                    <h3>Entity Relationship Graph Visualizer (Pivoting Engine)</h3>
                    <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 15px;">
                        Pivoting relationship topology across Users, Endpoints, Network IP Targets, and Malware IOC Signatures.
                    </p>
                    <div id="network-graph"></div>
                </div>
            </div>

            <!-- Threat Hunting Tab -->
            <div id="tab-hunting" class="tab-content">
                <div class="table-card">
                    <div class="table-header">
                        <h3>Normalized Telemetry Event Search Engine</h3>
                        <div style="display: flex; gap: 10px;">
                            <input type="text" id="hunting-query" placeholder="e.g. 192.168.1.100, Failed Login..." style="width: 300px;">
                            <button onclick="runHuntingQuery()">Execute Query</button>
                        </div>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Event ID</th>
                                <th>Timestamp</th>
                                <th>Source Type</th>
                                <th>Hostname</th>
                                <th>Source IP</th>
                                <th>User</th>
                                <th>Event Type</th>
                                <th>Severity</th>
                            </tr>
                        </thead>
                        <tbody id="hunting-results-body">
                            <tr><td colspan="8">Enter query to hunt telemetry events...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Asset Inventory Tab -->
            <div id="tab-assets" class="tab-content">
                <div class="table-card">
                    <div class="table-header">
                        <h3>Enterprise Asset Inventory & Risk Matrix</h3>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Asset ID</th>
                                <th>Hostname</th>
                                <th>IP Address</th>
                                <th>Operating System</th>
                                <th>Role</th>
                                <th>Criticality</th>
                                <th>Agent Status</th>
                                <th>Risk Score</th>
                            </tr>
                        </thead>
                        <tbody id="assets-body">
                            <tr><td colspan="8">Loading enterprise assets...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- MITRE ATT&CK Matrix Tab -->
            <div id="tab-mitre" class="tab-content">
                <div class="table-card" style="padding: 20px;">
                    <h3>MITRE ATT&CK Matrix Coverage Analyzer</h3>
                    <div id="mitre-matrix-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 10px; margin-top: 15px;">
                        <!-- Dynamically filled -->
                    </div>
                </div>
            </div>

            <!-- SOC Health Tab -->
            <div id="tab-health" class="tab-content">
                <div class="table-card">
                    <div class="table-header">
                        <h3>SOC Platform Infrastructure & Sensor Health Status</h3>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Integration / Service Name</th>
                                <th>Health Status</th>
                                <th>Details / Information</th>
                            </tr>
                        </thead>
                        <tbody id="health-body">
                            <tr><td colspan="3">Checking integration statuses...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- SOAR Playbooks Tab -->
            <div id="tab-playbooks" class="tab-content">
                <div class="table-card">
                    <div class="table-header">
                        <h3>SOAR Controlled Playbook Automation Center</h3>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Playbook ID</th>
                                <th>Name</th>
                                <th>Trigger Event</th>
                                <th>Requires Approval</th>
                                <th>Action Type</th>
                                <th>Run Dry-Run</th>
                            </tr>
                        </thead>
                        <tbody id="playbooks-body">
                            <tr><td colspan="6">Loading automation playbooks...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Reports Tab -->
            <div id="tab-reports" class="tab-content">
                <div class="card" style="margin-bottom: 20px;">
                    <h3>Export SOC Operations Reports</h3>
                    <p style="font-size: 0.85rem; color: var(--text-muted); margin: 10px 0;">
                        Download compliance audits, executive summaries, and incident response metrics.
                    </p>
                    <div style="display: flex; gap: 15px; margin-top: 15px;">
                        <button onclick="downloadReport('json')">Export Daily JSON Audit Report</button>
                        <button onclick="downloadReport('csv')">Export Alerts CSV Data</button>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <script>
        const API_BASE = "http://" + window.location.hostname + ":8001";

        function switchTab(tabId, el) {
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
            document.getElementById('tab-' + tabId).classList.add('active');
            el.classList.add('active');
            document.getElementById('tab-title').innerText = el.innerText;

            if (tabId === 'investigations') loadGraph();
            if (tabId === 'mitre') loadMitre();
            if (tabId === 'health') loadHealth();
            if (tabId === 'playbooks') loadPlaybooks();
            if (tabId === 'assets') loadAssets();
            if (tabId === 'incidents') loadIncidents();
        }

        async function fetchAPI(endpoint) {
            try {
                const res = await fetch(API_BASE + endpoint);
                return await res.json();
            } catch (e) {
                console.error("API error:", e);
                return null;
            }
        }

        async function refreshData() {
            const stats = await fetchAPI('/api/stats');
            if (stats) {
                document.getElementById('stat-alerts').innerText = stats.total_alerts || 0;
                document.getElementById('stat-incidents').innerText = stats.active_incidents || 0;
                document.getElementById('stat-assets').innerText = stats.total_assets || 5;
                document.getElementById('stat-events').innerText = stats.total_events || 14.2;
            }

            const alerts = await fetchAPI('/api/alerts?limit=25');
            if (alerts) {
                renderAlertsTable('dashboard-alerts-body', alerts.slice(0, 10), false);
                renderAlertsTable('all-alerts-body', alerts, true);
            }
        }

        function renderAlertsTable(targetId, alerts, showActions) {
            const tbody = document.getElementById(targetId);
            if (!alerts || alerts.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8">No security alerts found.</td></tr>';
                return;
            }
            tbody.innerHTML = alerts.map(a => `
                <tr>
                    <td><code>${a.id || 'ALT-01'}</code></td>
                    <td>${new Date(a.timestamp).toLocaleTimeString()}</td>
                    <td><strong>${a.title}</strong></td>
                    <td><span class="badge-sev sev-${(a.severity||'low').toLowerCase()}">${a.severity}</span></td>
                    <td>${a.source || '192.168.1.10'}</td>
                    ${showActions ? `<td>${a.mitre_technique || 'T1059'}</td>` : ''}
                    <td><strong>${a.risk_score || 50}</strong> / 100</td>
                    <td><span style="color: var(--status-online); font-size: 0.78rem;">${a.status || 'NEW'}</span></td>
                    ${showActions ? `<td><button onclick="resolveAlert('${a.id}')" style="padding: 4px 8px; font-size: 0.75rem;">Dismiss</button></td>` : ''}
                </tr>
            `).join('');
        }

        async function loadIncidents() {
            const incidents = await fetchAPI('/api/incidents');
            const tbody = document.getElementById('incidents-body');
            if (!incidents) return;
            tbody.innerHTML = incidents.map(i => `
                <tr>
                    <td><code>${i.id}</code></td>
                    <td><strong>${i.title}</strong></td>
                    <td><span class="badge-sev sev-${(i.severity||'high').toLowerCase()}">${i.severity}</span></td>
                    <td>${i.priority || 'P2'}</td>
                    <td><span class="badge-live">${i.status}</span></td>
                    <td>${i.category || 'Security Breach'}</td>
                    <td>${new Date(i.created_at).toLocaleString()}</td>
                    <td><button onclick="resolveIncident('${i.id}')" style="padding: 4px 8px; font-size: 0.75rem;">Resolve Incident</button></td>
                </tr>
            `).join('');
        }

        async function resolveIncident(incId) {
            await fetch(API_BASE + '/api/incidents/' + incId + '/resolve', { method: 'POST' });
            loadIncidents();
            refreshData();
        }

        async function loadAssets() {
            const assets = await fetchAPI('/api/assets');
            const tbody = document.getElementById('assets-body');
            if (!assets) return;
            tbody.innerHTML = assets.map(a => `
                <tr>
                    <td><code>${a.id}</code></td>
                    <td><strong>${a.hostname}</strong></td>
                    <td>${a.ip}</td>
                    <td>${a.os}</td>
                    <td>${a.role}</td>
                    <td><span class="badge-sev sev-${a.criticality.toLowerCase() === 'critical' ? 'critical' : 'medium'}">${a.criticality}</span></td>
                    <td><span class="badge-live">${a.agent_status}</span></td>
                    <td><strong>${a.risk_score}</strong> / 100</td>
                </tr>
            `).join('');
        }

        async function loadHealth() {
            const health = await fetchAPI('/api/soc/health');
            const tbody = document.getElementById('health-body');
            if (!health) return;
            tbody.innerHTML = health.services.map(s => `
                <tr>
                    <td><strong>${s.name}</strong></td>
                    <td><span class="badge-sev ${s.status === 'ONLINE' ? 'sev-low' : (s.status === 'SIMULATION' ? 'sev-medium' : 'sev-critical')}">${s.status}</span></td>
                    <td>${s.details}</td>
                </tr>
            `).join('');
        }

        async function loadPlaybooks() {
            const playbooks = await fetchAPI('/api/playbooks');
            const tbody = document.getElementById('playbooks-body');
            if (!playbooks) return;
            tbody.innerHTML = playbooks.map(p => `
                <tr>
                    <td><code>${p.id}</code></td>
                    <td><strong>${p.name}</strong></td>
                    <td>${p.trigger}</td>
                    <td>${p.requires_approval ? '<span class="badge-sev sev-high">Approval Required</span>' : '<span class="badge-sev sev-low">Auto</span>'}</td>
                    <td>${p.action_type}</td>
                    <td><button onclick="runPlaybook('${p.id}')" style="padding: 4px 8px; font-size: 0.75rem;">Run Dry-Run</button></td>
                </tr>
            `).join('');
        }

        async function runPlaybook(pbId) {
            const res = await fetch(API_BASE + '/api/playbooks/execute', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ playbook_id: pbId, target: '10.0.0.15', approved: true })
            });
            const data = await res.json();
            alert("Playbook Execution Status:\n" + JSON.stringify(data, null, 2));
        }

        async function loadGraph() {
            const graphData = await fetchAPI('/api/investigation/graph');
            if (!graphData) return;

            const container = document.getElementById('network-graph');
            const nodes = new vis.DataSet(graphData.nodes.map(n => ({
                id: n.id,
                label: n.label,
                shape: n.type === 'alert' ? 'diamond' : (n.type === 'user' ? 'icon' : 'box'),
                color: n.type === 'alert' ? '#ef4444' : (n.type === 'host' ? '#3b82f6' : '#06b6d4')
            })));
            const edges = new vis.DataSet(graphData.edges.map(e => ({ from: e.source, to: e.target, label: e.relationship })));
            
            new vis.Network(container, { nodes, edges }, {
                nodes: { font: { color: '#fff' } },
                edges: { font: { color: '#94a3b8', size: 10 }, color: '#1f293d' }
            });
        }

        async function loadMitre() {
            const data = await fetchAPI('/api/mitre/coverage');
            const container = document.getElementById('mitre-matrix-container');
            if (!data) return;

            container.innerHTML = Object.entries(data.matrix).map(([tactic, rules]) => `
                <div style="background: #0f172a; padding: 12px; border-radius: 6px; border: 1px solid var(--border-color);">
                    <div style="font-weight: 600; font-size: 0.8rem; margin-bottom: 8px; color: var(--accent-cyan);">${tactic}</div>
                    ${rules.length > 0 ? rules.map(r => `
                        <div style="background: var(--bg-card); padding: 6px; border-radius: 4px; font-size: 0.72rem; margin-bottom: 4px; border-left: 3px solid var(--accent-blue);">
                            <strong>${r.technique_id}</strong><br>${r.rule_name}
                        </div>
                    `).join('') : '<div style="font-size: 0.72rem; color: var(--text-muted);">No rules active</div>'}
                </div>
            `).join('');
        }

        async function runHuntingQuery() {
            const q = document.getElementById('hunting-query').value;
            const events = await fetchAPI('/api/hunting/events?q=' + encodeURIComponent(q));
            const tbody = document.getElementById('hunting-results-body');
            if (!events || events.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8">No matching telemetry events found.</td></tr>';
                return;
            }
            tbody.innerHTML = events.map(e => `
                <tr>
                    <td><code>${e.event_id}</code></td>
                    <td>${new Date(e.timestamp).toLocaleTimeString()}</td>
                    <td>${e.source_type}</td>
                    <td>${e.hostname}</td>
                    <td>${e.source_ip}</td>
                    <td>${e.username}</td>
                    <td><strong>${e.event_type}</strong></td>
                    <td><span class="badge-sev sev-${e.severity}">${e.severity}</span></td>
                </tr>
            `).join('');
        }

        function downloadReport(fmt) {
            window.open(API_BASE + '/api/reports/download?fmt=' + fmt, '_blank');
        }

        refreshData();
        setInterval(refreshData, 5000);
    </script>
</body>
</html>"""
