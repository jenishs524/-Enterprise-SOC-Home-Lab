from src.alert_rules import AlertRulesEngine

class MITRECoverageAnalyzer:
    def __init__(self):
        self.rules_engine = AlertRulesEngine()

    def get_coverage_matrix(self) -> dict:
        all_tactics = [
            "Reconnaissance", "Resource Development", "Initial Access", "Execution",
            "Persistence", "Privilege Escalation", "Defense Evasion", "Credential Access",
            "Discovery", "Lateral Movement", "Collection", "Command and Control",
            "Exfiltration", "Impact"
        ]

        active_rules = self.rules_engine.rules
        tactic_coverage = {tactic: [] for tactic in all_tactics}

        for rule in active_rules:
            tactic = rule.get("mitre_tactic", "Execution")
            if tactic in tactic_coverage:
                tactic_coverage[tactic].append({
                    "rule_id": rule["id"],
                    "rule_name": rule["name"],
                    "technique_id": rule.get("mitre_technique_id", "T1059"),
                    "technique_name": rule.get("mitre_technique_name", "General Technique"),
                    "severity": rule["severity"]
                })

        covered_count = sum(1 for t, rules in tactic_coverage.items() if len(rules) > 0)
        coverage_pct = round((covered_count / len(all_tactics)) * 100, 1)

        return {
            "total_tactics": len(all_tactics),
            "covered_tactics": covered_count,
            "coverage_percentage": coverage_pct,
            "matrix": tactic_coverage
        }
