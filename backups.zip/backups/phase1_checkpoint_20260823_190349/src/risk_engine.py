class RiskEngine:
    """
    Transparent Risk Model Calculator
    Formula: Risk = 0.25*Severity + 0.20*Confidence + 0.20*AssetCriticality + 0.15*IOCReputation + 0.20*AnomalyScore
    """
    def __init__(self):
        self.weights = {
            'severity': 0.25,
            'confidence': 0.20,
            'asset_criticality': 0.20,
            'ioc_reputation': 0.15,
            'anomaly_score': 0.20
        }

    def calculate_risk(self, alert_or_event: dict) -> dict:
        # 1. Severity Score (0 to 100)
        sev_str = str(alert_or_event.get('severity', 'medium')).lower()
        if sev_str == 'critical':
            sev_score = 100
        elif sev_str == 'high':
            sev_score = 75
        elif sev_str == 'medium':
            sev_score = 50
        else:
            sev_score = 25

        # 2. Confidence Score (0 to 100)
        confidence = float(alert_or_event.get('confidence', 80))

        # 3. Asset Criticality Score (0 to 100)
        crit_str = str(alert_or_event.get('asset_criticality', 'Medium')).lower()
        if crit_str in ['critical', 'high', 'domain-controller', 'db-server']:
            asset_score = 100
        elif crit_str == 'medium':
            asset_score = 60
        else:
            asset_score = 30

        # 4. IOC Reputation Score (0 to 100)
        ioc_rep = float(alert_or_event.get('ioc_reputation', 50))

        # 5. Anomaly Score (0 to 100)
        ml_anom = float(alert_or_event.get('anomaly_score', 0.5)) * 100

        # Weighted calculation
        total_risk = (
            self.weights['severity'] * sev_score +
            self.weights['confidence'] * confidence +
            self.weights['asset_criticality'] * asset_score +
            self.weights['ioc_reputation'] * ioc_rep +
            self.weights['anomaly_score'] * ml_anom
        )

        final_risk = int(min(max(round(total_risk), 0), 100))

        return {
            'risk_score': final_risk,
            'risk_level': 'CRITICAL' if final_risk >= 80 else ('HIGH' if final_risk >= 60 else ('MEDIUM' if final_risk >= 40 else 'LOW')),
            'breakdown': {
                'severity_component': round(self.weights['severity'] * sev_score, 1),
                'confidence_component': round(self.weights['confidence'] * confidence, 1),
                'asset_component': round(self.weights['asset_criticality'] * asset_score, 1),
                'ioc_component': round(self.weights['ioc_reputation'] * ioc_rep, 1),
                'anomaly_component': round(self.weights['anomaly_score'] * ml_anom, 1)
            },
            'formula': "Risk = 0.25*Sev + 0.20*Conf + 0.20*AssetCrit + 0.15*IOCRep + 0.20*AnomalyScore"
        }
