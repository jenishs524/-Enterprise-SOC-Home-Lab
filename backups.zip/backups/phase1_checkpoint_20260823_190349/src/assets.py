import json
from datetime import datetime
from src.database import Database

class AssetManager:
    def __init__(self, db: Database = None):
        self.db = db if db else Database()
        self._seed_default_assets()

    def _seed_default_assets(self):
        cursor = self.db.get_cursor()
        cursor.execute("SELECT COUNT(*) FROM assets")
        if cursor.fetchone()[0] == 0:
            default_assets = [
                ("AST-001", "DC-01.corp.internal", "10.0.0.10", "00:50:56:A1:00:01", "Windows Server 2022", "Domain Controller", "SecOps", "Production", "Critical", "DataCenter-1", "ONLINE", datetime.now().isoformat(), 85, json.dumps(["AD", "Identity"])),
                ("AST-002", "WEB-APP-01", "10.0.0.20", "00:50:56:A1:00:02", "Ubuntu 22.04 LTS", "Web Server", "DevOps", "Production", "High", "DMZ", "ONLINE", datetime.now().isoformat(), 45, json.dumps(["HTTP", "Frontend"])),
                ("AST-003", "DB-PROD-01", "10.0.0.30", "00:50:56:A1:00:03", "RHEL 9", "Database Server", "DBA", "Production", "Critical", "DataCenter-1", "ONLINE", datetime.now().isoformat(), 30, json.dumps(["PostgreSQL", "Data"])),
                ("AST-004", "WORKSTATION-77", "10.0.0.105", "00:50:56:A1:00:04", "Windows 11 Pro", "Workstation", "HR Dept", "Office", "Medium", "HQ-Fl3", "ONLINE", datetime.now().isoformat(), 65, json.dumps(["Endpoint", "User"])),
                ("AST-005", "FW-GATEWAY-01", "10.0.0.1", "00:50:56:A1:00:05", "PNSense/FreeBSD", "Network Firewall", "NetSec", "Production", "Critical", "Perimeter", "ONLINE", datetime.now().isoformat(), 15, json.dumps(["Firewall", "Gateway"]))
            ]
            cursor.executemany('''
                INSERT INTO assets (id, hostname, ip, mac, os, role, owner, environment, criticality, location, agent_status, last_seen, risk_score, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', default_assets)
            self.db.conn.commit()

    def get_assets(self) -> list:
        cursor = self.db.get_cursor()
        cursor.execute("SELECT * FROM assets ORDER BY risk_score DESC")
        rows = cursor.fetchall()
        assets = []
        for r in rows:
            d = dict(r)
            try:
                d['tags'] = json.loads(d['tags']) if d.get('tags') else []
            except:
                d['tags'] = []
            assets.append(d)
        return assets
