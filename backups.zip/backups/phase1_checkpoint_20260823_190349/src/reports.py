import json
import csv
import io
from datetime import datetime
from src.database import Database

class SOCReportGenerator:
    def __init__(self, db: Database = None):
        self.db = db if db else Database()

    def generate_json_report(self, report_type: str = "daily_soc") -> dict:
        stats = self.db.get_stats()
        alerts = self.db.get_alerts(limit=50)
        incidents = self.db.get_incidents(limit=20)

        return {
            "report_title": f"Enterprise SOC {report_type.replace('_', ' ').title()} Report",
            "generated_at": datetime.now().isoformat(),
            "environment": "Production Lab",
            "summary": {
                "total_alerts": stats.get("total_alerts", 0),
                "active_incidents": stats.get("active_incidents", 0),
                "total_incidents": stats.get("total_incidents", 0),
                "total_events": stats.get("total_events", 0)
            },
            "recent_incidents": incidents,
            "top_alerts": alerts[:10]
        }

    def generate_csv_report(self, report_type: str = "alerts") -> str:
        output = io.StringIO()
        writer = csv.writer(output)

        if report_type == "incidents":
            incidents = self.db.get_incidents(limit=100)
            writer.writerow(["Incident ID", "Title", "Severity", "Priority", "Status", "Created At", "Category", "MITRE ATT&CK"])
            for inc in incidents:
                writer.writerow([
                    inc.get("id"), inc.get("title"), inc.get("severity"), inc.get("priority"),
                    inc.get("status"), inc.get("created_at"), inc.get("category"), inc.get("mitre_attack")
                ])
        else:
            alerts = self.db.get_alerts(limit=100)
            writer.writerow(["Alert ID", "Title", "Severity", "Status", "Source", "Destination", "Timestamp", "Rule"])
            for alt in alerts:
                writer.writerow([
                    alt.get("id"), alt.get("title"), alt.get("severity"), alt.get("status"),
                    alt.get("source"), alt.get("destination"), alt.get("timestamp"), alt.get("detection_rule")
                ])

        return output.getvalue()
