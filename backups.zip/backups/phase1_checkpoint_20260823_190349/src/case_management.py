import json
import uuid
from datetime import datetime
from src.database import Database

class CaseManager:
    def __init__(self, db: Database = None):
        self.db = db if db else Database()

    def create_case(self, title: str, description: str, priority: str = "MEDIUM", lead_investigator: str = "SOC Analyst L2", related_incidents: list = None) -> dict:
        cursor = self.db.get_cursor()
        case_id = f"CASE-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6]}"
        now_str = datetime.now().isoformat()
        
        related_incidents = related_incidents or []
        tasks = [
            {"task_id": "T1", "title": "Initial Evidence Collection", "status": "COMPLETED", "assigned_to": lead_investigator},
            {"task_id": "T2", "title": "Endpoint Forensic Triage", "status": "IN_PROGRESS", "assigned_to": lead_investigator},
            {"task_id": "T3", "title": "Containment & Remediation Validation", "status": "PENDING", "assigned_to": lead_investigator}
        ]

        cursor.execute('''
            INSERT INTO cases (id, title, description, status, priority, lead_investigator, investigators, related_incidents, tasks, evidence, timeline, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            case_id,
            title,
            description,
            "OPEN",
            priority,
            lead_investigator,
            json.dumps([lead_investigator]),
            json.dumps(related_incidents),
            json.dumps(tasks),
            json.dumps([]),
            json.dumps([{"timestamp": now_str, "event": "Case Created", "by": lead_investigator}]),
            now_str,
            now_str
        ))
        self.db.conn.commit()
        return self.get_case(case_id)

    def get_case(self, case_id: str) -> dict:
        cursor = self.db.get_cursor()
        cursor.execute("SELECT * FROM cases WHERE id = ?", (case_id,))
        row = cursor.fetchone()
        if not row:
            return {}
        d = dict(row)
        for field in ['investigators', 'related_incidents', 'tasks', 'evidence', 'timeline']:
            try:
                d[field] = json.loads(d[field]) if d.get(field) else []
            except:
                d[field] = []
        return d

    def list_cases(self, limit: int = 50) -> list:
        cursor = self.db.get_cursor()
        cursor.execute("SELECT * FROM cases ORDER BY created_at DESC LIMIT ?", (limit,))
        rows = cursor.fetchall()
        cases = []
        for r in rows:
            d = dict(r)
            for field in ['investigators', 'related_incidents', 'tasks', 'evidence', 'timeline']:
                try:
                    d[field] = json.loads(d[field]) if d.get(field) else []
                except:
                    d[field] = []
            cases.append(d)
        return cases
