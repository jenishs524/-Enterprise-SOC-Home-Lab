import os
import requests
import json
import ipaddress
from datetime import datetime

class ThreatIntel:
    """
    Threat Intelligence Enrichment Service
    Integrates with AbuseIPDB, VirusTotal, and Local IOC Intelligence Feeds.
    """
    def __init__(self):
        self.abuseipdb_key = os.getenv("ABUSEIPDB_API_KEY", "")
        self.virustotal_key = os.getenv("VIRUSTOTAL_API_KEY", "")
        self.local_iocs = {
            "ips": {"192.168.1.195": "Data Exfiltration Target", "192.168.1.99": "Suspicious Scanner", "185.220.101.5": "Known Tor Exit Node"},
            "domains": {"malicious-863.com": "C2 Domain", "evil-phish.net": "Phishing Landing Page"},
            "hashes": {"44d88612fea8a8f36de82e1278abb02f": "EICAR Test File", "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855": "Empty Hash"}
        }

    def check_ip(self, ip: str) -> dict:
        if not ip or ip == "0.0.0.0" or ip.startswith("127."):
            return {"malicious": False, "score": 0, "source": "local"}

        if ip in self.local_iocs["ips"]:
            return {
                "malicious": True,
                "score": 95,
                "source": "Local Threat Intel Feed",
                "details": self.local_iocs["ips"][ip]
            }

        if self.abuseipdb_key:
            try:
                res = requests.get(
                    "https://api.abuseipdb.com/api/v2/check",
                    params={"ipAddress": ip, "maxAgeInDays": 90},
                    headers={"Key": self.abuseipdb_key, "Accept": "application/json"},
                    timeout=3
                )
                if res.status_code == 200:
                    data = res.json().get("data", {})
                    score = data.get("abuseConfidenceScore", 0)
                    return {
                        "malicious": score > 50,
                        "score": score,
                        "source": "AbuseIPDB API",
                        "details": f"Abuse confidence {score}% with {data.get('totalReports', 0)} reports"
                    }
            except Exception:
                pass

        return {"malicious": False, "score": 10, "source": "Passive Reputation Cache"}

    def check_domain(self, domain: str) -> dict:
        if domain in self.local_iocs["domains"]:
            return {
                "malicious": True,
                "score": 90,
                "source": "Local Threat Intel Feed",
                "details": self.local_iocs["domains"][domain]
            }
        return {"malicious": False, "score": 0, "source": "Domain Cache"}

    def check_hash(self, file_hash: str) -> dict:
        if file_hash in self.local_iocs["hashes"]:
            return {
                "malicious": True,
                "score": 100,
                "source": "Local Malware Family Cache",
                "details": self.local_iocs["hashes"][file_hash]
            }
        return {"malicious": False, "score": 0, "source": "Hash Cache"}

    def enrich_alert(self, alert: dict) -> dict:
        enriched = dict(alert)
        ip = alert.get("source") or alert.get("source_ip")
        if ip:
            ti_res = self.check_ip(str(ip))
            enriched["threat_intel"] = ti_res
            if ti_res.get("malicious"):
                enriched["risk_score"] = min(int(enriched.get("risk_score", 50)) + 35, 100)
        return enriched
