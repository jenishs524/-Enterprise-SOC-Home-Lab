import json
from datetime import datetime
from src.audit import AuditLogger

class PlaybookEngine:
    """
    Controlled Automation Layer for SOC Playbooks.
    Destructive actions MUST require explicit analyst approval.
    """
    def __init__(self):
        self.audit_logger = AuditLogger()
        self.playbooks = [
            {
                "id": "PB-001",
                "name": "Automated IP Reputation Enrichment",
                "trigger": "BRUTE_FORCE / REPEATED_FAILURES",
                "description": "Automatically queries threat feeds for attacking IP address",
                "requires_approval": False,
                "action_type": "ENRICHMENT"
            },
            {
                "id": "PB-002",
                "name": "Endpoint Host Isolation (Dry Run)",
                "trigger": "RANSOMWARE / MALWARE_EXECUTION",
                "description": "Isolates compromised workstation network interfaces. Requires Analyst Approval.",
                "requires_approval": True,
                "action_type": "CONTAINMENT"
            },
            {
                "id": "PB-003",
                "name": "User Account Lockout Request",
                "trigger": "CREDENTIAL_ACCESS / IMPOSSIBLE_TRAVEL",
                "description": "Suspends Active Directory user tokens. Requires Analyst Approval.",
                "requires_approval": True,
                "action_type": "CONTAINMENT"
            }
        ]

    def get_playbooks(self) -> list:
        return self.playbooks

    def execute_playbook(self, playbook_id: str, target: str, executed_by: str = "Analyst", approved: bool = False) -> dict:
        pb = next((p for p in self.playbooks if p["id"] == playbook_id), None)
        if not pb:
            return {"status": "FAILED", "reason": f"Playbook {playbook_id} not found"}

        if pb["requires_approval"] and not approved:
            return {
                "status": "PENDING_APPROVAL",
                "playbook_id": playbook_id,
                "name": pb["name"],
                "target": target,
                "message": f"Execution of {pb['name']} on target '{target}' requires explicit analyst approval."
            }

        # Execute safe dry-run in lab environment
        now_str = datetime.now().isoformat()
        result = {
            "status": "SUCCESS",
            "playbook_id": playbook_id,
            "name": pb["name"],
            "target": target,
            "executed_by": executed_by,
            "timestamp": now_str,
            "details": f"Dry-run executed for {pb['action_type']} on {target}. Firewall rule / API payload logged successfully."
        }

        self.audit_logger.log(
            username=executed_by,
            role="Analyst",
            action=f"EXECUTE_PLAYBOOK_{pb['action_type']}",
            target_type="PLAYBOOK",
            target_id=playbook_id,
            old_value="",
            new_value=json.dumps(result)
        )

        return result
