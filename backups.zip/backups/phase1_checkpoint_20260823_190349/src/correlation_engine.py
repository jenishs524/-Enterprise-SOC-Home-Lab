#!/usr/bin/env python3
"""
Advanced Correlation Engine with ML
"""

import json
from datetime import datetime, timedelta
from collections import defaultdict
import numpy as np
from sklearn.cluster import DBSCAN

class CorrelationEngine:
    def __init__(self):
        self.alerts_history = []
        self.correlations = []
        self.clusterer = DBSCAN(eps=0.5, min_samples=3)
    
    def add_alert(self, alert):
        """Add an alert to history"""
        self.alerts_history.append({
            **alert,
            'timestamp': datetime.now().isoformat()
        })
        
        # Keep last 1000 alerts
        if len(self.alerts_history) > 1000:
            self.alerts_history = self.alerts_history[-1000:]
        
        # Try to correlate
        self._correlate()
    
    def _correlate(self):
        """Correlate alerts using ML and rules"""
        if len(self.alerts_history) < 3:
            return []
        
        # Extract features
        recent_alerts = self.alerts_history[-10:]
        features = []
        for alert in recent_alerts:
            feat = [
                len(alert.get('title', '')),
                len(alert.get('description', '')),
                1 if alert.get('severity') == 'critical' else 0,
                1 if alert.get('severity') == 'high' else 0,
            ]
            features.append(feat)
        
        if len(features) >= 3:
            X = np.array(features)
            clusters = self.clusterer.fit_predict(X)
            
            # Find correlated alerts
            for cluster_id in set(clusters):
                if cluster_id == -1:
                    continue
                
                cluster_alerts = [
                    recent_alerts[i] 
                    for i in range(len(recent_alerts)) 
                    if clusters[i] == cluster_id
                ]
                
                if len(cluster_alerts) >= 3:
                    correlation = {
                        'id': f"CORR-{datetime.now().strftime('%Y%m%d%H%M%S')}",
                        'type': 'ml_cluster',
                        'alerts': cluster_alerts,
                        'count': len(cluster_alerts),
                        'timestamp': datetime.now().isoformat(),
                        'severity': max(a.get('severity', 'low') for a in cluster_alerts)
                    }
                    self.correlations.append(correlation)
                    return [correlation]
        
        return []
    
    def find_patterns(self):
        """Find patterns in alerts"""
        patterns = []
        
        # Time-based patterns
        if len(self.alerts_history) > 10:
            recent = self.alerts_history[-10:]
            # Check for same source
            sources = defaultdict(list)
            for alert in recent:
                src = alert.get('source', 'unknown')
                sources[src].append(alert)
            
            for src, alerts in sources.items():
                if len(alerts) >= 3:
                    # Check if they're the same type
                    types = set(a.get('title', '') for a in alerts)
                    if len(types) <= 2:
                        patterns.append({
                            'type': 'repeated_attacks',
                            'source': src,
                            'count': len(alerts),
                            'alerts': alerts,
                            'timestamp': datetime.now().isoformat()
                        })
        
        return patterns

# Test
if __name__ == "__main__":
    engine = CorrelationEngine()
    
    # Add test alerts
    alerts = [
        {'title': 'Port Scan', 'severity': 'high', 'source': '192.168.1.100'},
        {'title': 'Port Scan', 'severity': 'high', 'source': '192.168.1.100'},
        {'title': 'Port Scan', 'severity': 'high', 'source': '192.168.1.100'},
        {'title': 'Malware', 'severity': 'critical', 'source': '192.168.1.200'},
    ]
    
    for alert in alerts:
        engine.add_alert(alert)
    
    patterns = engine.find_patterns()
    print(f"Found patterns: {patterns}")
