import sqlite3
import json
import os
from datetime import datetime

class Database:
    def __init__(self, db_path=None):
        if db_path is None:
            # Default to absolute path in workspace root
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_path = os.path.join(base_dir, "soc_data.db")
        
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.create_tables()

    def get_cursor(self):
        return self.conn.cursor()

    def create_tables(self):
        cursor = self.conn.cursor()
        
        # 1. Normalized Events Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS events (
                event_id TEXT PRIMARY KEY,
                timestamp TEXT,
                source_type TEXT,
                source_product TEXT,
                hostname TEXT,
                source_ip TEXT,
                destination_ip TEXT,
                source_port INTEGER DEFAULT 0,
                destination_port INTEGER DEFAULT 0,
                username TEXT,
                process_name TEXT,
                event_type TEXT,
                severity TEXT DEFAULT 'medium',
                risk_score INTEGER DEFAULT 0,
                raw_event TEXT,
                normalized_event TEXT,
                environment TEXT DEFAULT 'lab'
            )
        ''')
        
        # 2. Alerts Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS alerts (
                id TEXT PRIMARY KEY,
                title TEXT,
                severity TEXT,
                description TEXT,
                source TEXT,
                destination TEXT,
                timestamp TEXT,
                indicators TEXT,
                status TEXT DEFAULT 'NEW',
                confidence INTEGER DEFAULT 80,
                risk_score INTEGER DEFAULT 50,
                affected_asset TEXT,
                affected_user TEXT,
                mitre_tactic TEXT,
                mitre_technique TEXT,
                detection_rule TEXT,
                first_seen TEXT,
                last_seen TEXT,
                occurrence_count INTEGER DEFAULT 1,
                assignee TEXT,
                evidence TEXT,
                analyst_notes TEXT,
                processed BOOLEAN DEFAULT 0
            )
        ''')

        # Add missing columns dynamically to existing alerts table if needed
        self._ensure_columns("alerts", {
            "status": "TEXT DEFAULT 'NEW'",
            "confidence": "INTEGER DEFAULT 80",
            "risk_score": "INTEGER DEFAULT 50",
            "source": "TEXT DEFAULT 'system'",
            "destination": "TEXT DEFAULT ''",
            "affected_asset": "TEXT DEFAULT ''",
            "affected_user": "TEXT DEFAULT ''",
            "mitre_tactic": "TEXT DEFAULT ''",
            "mitre_technique": "TEXT DEFAULT ''",
            "detection_rule": "TEXT DEFAULT ''",
            "first_seen": "TEXT DEFAULT ''",
            "last_seen": "TEXT DEFAULT ''",
            "occurrence_count": "INTEGER DEFAULT 1",
            "assignee": "TEXT DEFAULT 'Unassigned'",
            "evidence": "TEXT DEFAULT '[]'",
            "analyst_notes": "TEXT DEFAULT '[]'",
            "processed": "BOOLEAN DEFAULT 0"
        })
        
        # 3. Incidents Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS incidents (
                id TEXT PRIMARY KEY,
                title TEXT,
                severity TEXT,
                priority TEXT DEFAULT 'P2',
                status TEXT DEFAULT 'open',
                category TEXT DEFAULT 'Security Breach',
                created_at TEXT,
                resolved_at TEXT,
                alert_id TEXT,
                description TEXT,
                mitre_attack TEXT,
                affected_assets TEXT DEFAULT '[]',
                affected_users TEXT DEFAULT '[]',
                related_alerts TEXT DEFAULT '[]',
                evidence TEXT DEFAULT '[]',
                timeline TEXT DEFAULT '[]',
                ioc_list TEXT DEFAULT '[]',
                analysts TEXT DEFAULT '[]',
                tasks TEXT DEFAULT '[]',
                notes TEXT DEFAULT '[]',
                containment TEXT DEFAULT '',
                eradication TEXT DEFAULT '',
                recovery TEXT DEFAULT '',
                root_cause TEXT DEFAULT '',
                lessons_learned TEXT DEFAULT '',
                closure_reason TEXT DEFAULT ''
            )
        ''')

        self._ensure_columns("incidents", {
            "priority": "TEXT DEFAULT 'P2'",
            "category": "TEXT DEFAULT 'Security Incident'",
            "mitre_attack": "TEXT DEFAULT ''",
            "affected_assets": "TEXT DEFAULT '[]'",
            "affected_users": "TEXT DEFAULT '[]'",
            "related_alerts": "TEXT DEFAULT '[]'",
            "evidence": "TEXT DEFAULT '[]'",
            "timeline": "TEXT DEFAULT '[]'",
            "ioc_list": "TEXT DEFAULT '[]'",
            "analysts": "TEXT DEFAULT '[]'",
            "tasks": "TEXT DEFAULT '[]'",
            "notes": "TEXT DEFAULT '[]'",
            "containment": "TEXT DEFAULT ''",
            "eradication": "TEXT DEFAULT ''",
            "recovery": "TEXT DEFAULT ''",
            "root_cause": "TEXT DEFAULT ''",
            "lessons_learned": "TEXT DEFAULT ''",
            "closure_reason": "TEXT DEFAULT ''"
        })

        # 4. Cases Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cases (
                id TEXT PRIMARY KEY,
                title TEXT,
                description TEXT,
                status TEXT DEFAULT 'OPEN',
                priority TEXT DEFAULT 'MEDIUM',
                lead_investigator TEXT DEFAULT 'Admin',
                investigators TEXT DEFAULT '[]',
                related_incidents TEXT DEFAULT '[]',
                tasks TEXT DEFAULT '[]',
                evidence TEXT DEFAULT '[]',
                timeline TEXT DEFAULT '[]',
                created_at TEXT,
                updated_at TEXT
            )
        ''')

        # 5. Asset Inventory Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS assets (
                id TEXT PRIMARY KEY,
                hostname TEXT UNIQUE,
                ip TEXT,
                mac TEXT,
                os TEXT,
                role TEXT,
                owner TEXT,
                environment TEXT DEFAULT 'Production',
                criticality TEXT DEFAULT 'Medium',
                location TEXT DEFAULT 'DataCenter-1',
                agent_status TEXT DEFAULT 'ONLINE',
                last_seen TEXT,
                risk_score INTEGER DEFAULT 20,
                tags TEXT DEFAULT '[]'
            )
        ''')

        # 6. Users & Identity Table (RBAC)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                username TEXT UNIQUE,
                password_hash TEXT,
                email TEXT,
                role TEXT DEFAULT 'SOC Analyst L1',
                permissions TEXT DEFAULT '[]',
                is_active INTEGER DEFAULT 1,
                created_at TEXT,
                last_login TEXT
            )
        ''')

        # 7. Audit Log Table (Append-only)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                username TEXT,
                role TEXT,
                action TEXT,
                target_type TEXT,
                target_id TEXT,
                old_value TEXT,
                new_value TEXT,
                ip_address TEXT,
                status TEXT DEFAULT 'SUCCESS'
            )
        ''')

        # 8. Threat Intelligence Indicators Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS threat_intel (
                id TEXT PRIMARY KEY,
                indicator TEXT UNIQUE,
                indicator_type TEXT,
                source TEXT,
                confidence INTEGER DEFAULT 80,
                severity TEXT DEFAULT 'high',
                first_seen TEXT,
                last_seen TEXT,
                tags TEXT DEFAULT '[]',
                malware_family TEXT DEFAULT '',
                threat_actor TEXT DEFAULT '',
                references_info TEXT DEFAULT '[]'
            )
        ''')

        # 9. Detection Rules Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS detection_rules (
                id TEXT PRIMARY KEY,
                rule_name TEXT UNIQUE,
                description TEXT,
                severity TEXT DEFAULT 'high',
                category TEXT DEFAULT 'Threat Detection',
                mitre_tactic TEXT,
                mitre_technique_id TEXT,
                mitre_technique_name TEXT,
                rule_type TEXT DEFAULT 'correlation',
                rule_logic TEXT,
                enabled INTEGER DEFAULT 1,
                created_by TEXT DEFAULT 'System',
                created_at TEXT
            )
        ''')

        # 10. SOAR Playbooks Table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS playbooks (
                id TEXT PRIMARY KEY,
                playbook_name TEXT UNIQUE,
                trigger_event TEXT,
                description TEXT,
                actions TEXT DEFAULT '[]',
                requires_approval INTEGER DEFAULT 1,
                enabled INTEGER DEFAULT 1
            )
        ''')

        # Indexes for Performance
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_ts ON events(timestamp)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_src_ip ON events(source_ip)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_dst_ip ON events(destination_ip)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_incidents_status ON incidents(status)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_logs(timestamp)")

        self.conn.commit()

    def _ensure_columns(self, table_name, columns_dict):
        cursor = self.conn.cursor()
        cursor.execute(f"PRAGMA table_info({table_name})")
        existing_cols = {row["name"] for row in cursor.fetchall()}
        for col_name, col_def in columns_dict.items():
            if col_name not in existing_cols:
                try:
                    cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {col_name} {col_def}")
                except Exception as e:
                    pass
        self.conn.commit()

    def save_alert(self, alert):
        cursor = self.conn.cursor()
        now_str = datetime.now().isoformat()
        cursor.execute('''
            INSERT OR REPLACE INTO alerts 
            (id, title, severity, description, source, destination, timestamp, indicators, status,
             confidence, risk_score, affected_asset, affected_user, mitre_tactic, mitre_technique,
             detection_rule, first_seen, last_seen, occurrence_count, assignee, evidence, analyst_notes, processed)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            alert.get('id'),
            alert.get('title'),
            alert.get('severity', 'medium'),
            alert.get('description', ''),
            alert.get('source', 'system'),
            alert.get('destination', ''),
            alert.get('timestamp', now_str),
            json.dumps(alert.get('indicators', [])) if isinstance(alert.get('indicators'), list) else str(alert.get('indicators', '[]')),
            alert.get('status', 'NEW'),
            alert.get('confidence', 80),
            alert.get('risk_score', 50),
            alert.get('affected_asset', alert.get('source', 'Unknown Host')),
            alert.get('affected_user', 'System'),
            alert.get('mitre_tactic', 'Defense Evasion'),
            alert.get('mitre_technique', 'T1078'),
            alert.get('detection_rule', 'Default Rule'),
            alert.get('first_seen', now_str),
            alert.get('last_seen', now_str),
            alert.get('occurrence_count', 1),
            alert.get('assignee', 'Unassigned'),
            json.dumps(alert.get('evidence', [])) if isinstance(alert.get('evidence'), list) else str(alert.get('evidence', '[]')),
            json.dumps(alert.get('analyst_notes', [])) if isinstance(alert.get('analyst_notes'), list) else str(alert.get('analyst_notes', '[]')),
            1 if alert.get('processed') else 0
        ))
        self.conn.commit()

    def save_incident(self, incident):
        cursor = self.conn.cursor()
        now_str = datetime.now().isoformat()
        cursor.execute('''
            INSERT OR REPLACE INTO incidents
            (id, title, severity, priority, status, category, created_at, alert_id, description,
             mitre_attack, affected_assets, affected_users, related_alerts, evidence, timeline, ioc_list, analysts)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            incident.get('id'),
            incident.get('title'),
            incident.get('severity', 'high'),
            incident.get('priority', 'P2'),
            incident.get('status', 'open'),
            incident.get('category', 'Security Breach'),
            incident.get('created_at', now_str),
            incident.get('alert_id', ''),
            incident.get('description', ''),
            incident.get('mitre_attack', 'T1110 - Brute Force'),
            json.dumps(incident.get('affected_assets', [])) if isinstance(incident.get('affected_assets'), list) else str(incident.get('affected_assets', '[]')),
            json.dumps(incident.get('affected_users', [])) if isinstance(incident.get('affected_users'), list) else str(incident.get('affected_users', '[]')),
            json.dumps(incident.get('related_alerts', [])) if isinstance(incident.get('related_alerts'), list) else str(incident.get('related_alerts', '[]')),
            json.dumps(incident.get('evidence', [])) if isinstance(incident.get('evidence'), list) else str(incident.get('evidence', '[]')),
            json.dumps(incident.get('timeline', [])) if isinstance(incident.get('timeline'), list) else str(incident.get('timeline', '[]')),
            json.dumps(incident.get('ioc_list', [])) if isinstance(incident.get('ioc_list'), list) else str(incident.get('ioc_list', '[]')),
            json.dumps(incident.get('analysts', ['SOC Analyst L1'])) if isinstance(incident.get('analysts'), list) else str(incident.get('analysts', '["SOC Analyst L1"]'))
        ))
        self.conn.commit()

    def get_stats(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM alerts")
        alerts_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM incidents WHERE status != 'resolved'")
        active_incidents = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM incidents")
        total_incidents = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM events")
        events_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM assets")
        assets_count = cursor.fetchone()[0]
        return {
            'total_alerts': alerts_count,
            'active_incidents': active_incidents,
            'total_incidents': total_incidents,
            'total_events': events_count,
            'total_assets': assets_count
        }

    def get_alerts(self, limit=100):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM alerts ORDER BY timestamp DESC LIMIT ?", (limit,))
        rows = cursor.fetchall()
        alerts = []
        for r in rows:
            dict_r = dict(r)
            try:
                dict_r['indicators'] = json.loads(dict_r['indicators']) if dict_r.get('indicators') else []
            except:
                dict_r['indicators'] = []
            alerts.append(dict_r)
        return alerts

    def get_incidents(self, limit=50):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM incidents ORDER BY created_at DESC LIMIT ?", (limit,))
        rows = cursor.fetchall()
        incidents = []
        for r in rows:
            dict_r = dict(r)
            for field in ['affected_assets', 'affected_users', 'related_alerts', 'evidence', 'timeline', 'ioc_list', 'analysts']:
                try:
                    dict_r[field] = json.loads(dict_r[field]) if dict_r.get(field) else []
                except:
                    dict_r[field] = []
            incidents.append(dict_r)
        return incidents

    def close(self):
        self.conn.close()
