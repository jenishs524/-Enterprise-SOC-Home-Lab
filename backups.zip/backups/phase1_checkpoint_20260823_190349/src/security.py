import os
import hashlib
import hmac
import time
import json
import base64

SECRET_KEY = os.getenv("JWT_SECRET", "soc-lab-super-secret-key-change-in-production")

ROLES_PERMISSIONS = {
    "SOC Analyst L1": ["alerts.read", "alerts.update", "incidents.read"],
    "SOC Analyst L2": ["alerts.read", "alerts.update", "incidents.read", "incidents.update", "cases.read", "hunting.read"],
    "Threat Hunter": ["alerts.read", "incidents.read", "hunting.read", "hunting.write", "threat_intel.read"],
    "Incident Responder": ["alerts.read", "incidents.read", "incidents.update", "incidents.close", "cases.read", "cases.write", "playbooks.read", "playbooks.execute"],
    "Detection Engineer": ["alerts.read", "rules.read", "rules.write", "mitre.read"],
    "SOC Manager": ["alerts.read", "incidents.read", "cases.read", "reports.read", "reports.generate", "admin.audit"],
    "Administrator": ["*"],
    "Read Only": ["*.read"]
}

def hash_password(password: str, salt: str = None) -> str:
    if not salt:
        salt = os.urandom(16).hex()
    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000)
    return f"{salt}${key.hex()}"

def verify_password(password: str, stored_hash: str) -> bool:
    try:
        salt, key_hex = stored_hash.split('$')
        recalculated = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000)
        return hmac.compare_digest(recalculated.hex(), key_hex)
    except Exception:
        return False

def generate_token(username: str, role: str, expires_in_seconds: int = 86400) -> str:
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {
        "sub": username,
        "role": role,
        "iat": int(time.time()),
        "exp": int(time.time()) + expires_in_seconds
    }
    
    header_b64 = base64.urlsafe_b64encode(json.dumps(header).encode()).decode().rstrip("=")
    payload_b64 = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip("=")
    
    signature_input = f"{header_b64}.{payload_b64}".encode()
    signature = hmac.new(SECRET_KEY.encode(), signature_input, hashlib.sha256).digest()
    sig_b64 = base64.urlsafe_b64encode(signature).decode().rstrip("=")
    
    return f"{header_b64}.{payload_b64}.{sig_b64}"

def verify_token(token: str):
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        header_b64, payload_b64, sig_b64 = parts
        
        # Verify signature
        signature_input = f"{header_b64}.{payload_b64}".encode()
        expected_sig = hmac.new(SECRET_KEY.encode(), signature_input, hashlib.sha256).digest()
        actual_sig = base64.urlsafe_b64decode(sig_b64 + "==")
        
        if not hmac.compare_digest(expected_sig, actual_sig):
            return None
        
        payload_json = base64.urlsafe_b64decode(payload_b64 + "==").decode()
        payload = json.loads(payload_json)
        
        if payload.get("exp", 0) < time.time():
            return None
            
        return payload
    except Exception:
        return None

def has_permission(role: str, required_permission: str) -> bool:
    role_perms = ROLES_PERMISSIONS.get(role, [])
    if "*" in role_perms:
        return True
    if required_permission in role_perms:
        return True
    
    prefix = required_permission.split(".")[0]
    if f"{prefix}.*" in role_perms or "*.read" in role_perms and required_permission.endswith(".read"):
        return True
        
    return False
