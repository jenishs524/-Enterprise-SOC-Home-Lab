import json
from datetime import datetime
from src.database import Database

class InvestigationWorkspace:
    def __init__(self, db: Database = None):
        self.db = db if db else Database()

    def get_entity_graph(self, entity_type: str = "all", entity_id: str = "") -> dict:
        """
        Builds entity relationship graph nodes and edges for SOC investigation pivoting.
        Pivots: User -> Host -> Process -> IP -> IOC -> Alerts -> Incidents
        """
        nodes = []
        edges = []
        node_set = set()

        def add_node(node_id: str, label: str, node_type: str, severity: str = "low"):
            if node_id not in node_set:
                node_set.add(node_id)
                nodes.append({
                    "id": node_id,
                    "label": label,
                    "type": node_type,
                    "severity": severity
                })

        def add_edge(source: str, target: str, relationship: str):
            edges.append({
                "source": source,
                "target": target,
                "relationship": relationship
            })

        alerts = self.db.get_alerts(limit=50)
        for alert in alerts:
            alert_node_id = f"ALERT-{alert['id']}"
            host = alert.get('source') or alert.get('affected_asset', 'Host-01')
            user = alert.get('affected_user', 'admin')
            dst_ip = alert.get('destination', '10.0.0.1')
            rule = alert.get('detection_rule', 'Security Violation')

            host_node_id = f"HOST-{host}"
            user_node_id = f"USER-{user}"
            ip_node_id = f"IP-{dst_ip}"
            ioc_node_id = f"IOC-{rule}"

            add_node(alert_node_id, alert['title'], "alert", alert.get('severity', 'high'))
            add_node(host_node_id, host, "host", "medium")
            add_node(user_node_id, user, "user", "medium")
            add_node(ip_node_id, dst_ip, "ip", "high")
            add_node(ioc_node_id, rule, "ioc", "critical")

            add_edge(user_node_id, host_node_id, "logged_into")
            add_edge(host_node_id, ip_node_id, "connected_to")
            add_edge(ip_node_id, ioc_node_id, "matched_ioc")
            add_edge(host_node_id, alert_node_id, "generated_alert")

        return {
            "nodes": nodes,
            "edges": edges,
            "total_nodes": len(nodes),
            "total_edges": len(edges)
        }

    def get_timeline(self, limit: int = 50) -> list:
        alerts = self.db.get_alerts(limit=limit)
        timeline = []
        for alert in alerts:
            timeline.append({
                "timestamp": alert.get('timestamp'),
                "type": "ALERT",
                "id": alert.get('id'),
                "title": alert.get('title'),
                "severity": alert.get('severity'),
                "entity": alert.get('source'),
                "description": alert.get('description')
            })
        timeline.sort(key=lambda x: x['timestamp'], reverse=True)
        return timeline
