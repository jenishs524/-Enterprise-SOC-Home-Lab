import json
import re
from datetime import datetime
from collections import defaultdict

class AlertRulesEngine:
    def __init__(self):
        self.rules = self._default_rules()
        self.event_history = defaultdict(list)

    def _default_rules(self):
        return [
            {
                'id': 'RULE-T1110',
                'name': 'Brute Force Attack (T1110)',
                'severity': 'high',
                'category': 'Credential Access',
                'mitre_tactic': 'Credential Access',
                'mitre_technique_id': 'T1110',
                'mitre_technique_name': 'Brute Force',
                'type': 'threshold',
                'condition': {'field': 'event_type', 'operator': 'contains', 'value': 'Failed Login'},
                'threshold_count': 5,
                'time_window_seconds': 60,
                'description': 'Multiple failed authentication attempts detected within short interval.'
            },
            {
                'id': 'RULE-T1059',
                'name': 'Suspicious Execution (T1059)',
                'severity': 'critical',
                'category': 'Execution',
                'mitre_tactic': 'Execution',
                'mitre_technique_id': 'T1059',
                'mitre_technique_name': 'Command and Scripting Interpreter',
                'type': 'signature',
                'condition': {'field': 'process_name', 'operator': 'regex', 'value': r'(powershell|cmd|bash|nc|ncat|netcat|mimikatz|psexec|certutil)'},
                'description': 'Execution of sensitive command-line utility or scripting shell.'
            },
            {
                'id': 'RULE-T1068',
                'name': 'Privilege Escalation Attempt (T1068)',
                'severity': 'critical',
                'category': 'Privilege Escalation',
                'mitre_tactic': 'Privilege Escalation',
                'mitre_technique_id': 'T1068',
                'mitre_technique_name': 'Exploitation for Privilege Escalation',
                'type': 'signature',
                'condition': {'field': 'event_type', 'operator': 'contains', 'value': 'Privilege Escalation'},
                'description': 'Attempt to elevate system rights or leverage administrative token.'
            },
            {
                'id': 'RULE-T1041',
                'name': 'Data Exfiltration (T1041)',
                'severity': 'critical',
                'category': 'Exfiltration',
                'mitre_tactic': 'Exfiltration',
                'mitre_technique_id': 'T1041',
                'mitre_technique_name': 'Exfiltration Over C2 Channel',
                'type': 'threshold',
                'condition': {'field': 'event_type', 'operator': 'contains', 'value': 'Exfiltration'},
                'description': 'Large outbound data transfer or exfiltration pattern detected.'
            },
            {
                'id': 'RULE-T1071',
                'name': 'DNS Tunneling / C2 Channel (T1071)',
                'severity': 'high',
                'category': 'Command and Control',
                'mitre_tactic': 'Command and Control',
                'mitre_technique_id': 'T1071',
                'mitre_technique_name': 'Application Layer Protocol',
                'type': 'signature',
                'condition': {'field': 'event_type', 'operator': 'contains', 'value': 'DNS Tunneling'},
                'description': 'Unusual high-entropy DNS queries indicative of C2 tunneling.'
            },
            {
                'id': 'RULE-T1046',
                'name': 'Network Port Scan (T1046)',
                'severity': 'high',
                'category': 'Reconnaissance',
                'mitre_tactic': 'Reconnaissance',
                'mitre_technique_id': 'T1046',
                'mitre_technique_name': 'Network Service Discovery',
                'type': 'signature',
                'condition': {'field': 'event_type', 'operator': 'contains', 'value': 'Port Scan'},
                'description': 'Sequential scanning of open network ports across internal subnets.'
            }
        ]

    def evaluate_event(self, event):
        alerts = []
        source = event.get('source_ip', event.get('source', 'unknown'))
        self.event_history[source].append(event)
        
        for rule in self.rules:
            if self._check_rule(rule, event):
                alert = {
                    'id': f"ALERT-{datetime.now().strftime('%Y%m%d%H%M%S')}-{rule['id']}",
                    'rule_id': rule['id'],
                    'title': rule['name'],
                    'severity': rule['severity'],
                    'description': rule['description'],
                    'source': event.get('source_ip', event.get('hostname', 'unknown')),
                    'destination': event.get('destination_ip', '0.0.0.0'),
                    'affected_asset': event.get('hostname', 'unknown'),
                    'affected_user': event.get('username', 'System'),
                    'mitre_tactic': rule['mitre_tactic'],
                    'mitre_technique': f"{rule['mitre_technique_id']} - {rule['mitre_technique_name']}",
                    'detection_rule': rule['name'],
                    'confidence': 85,
                    'timestamp': datetime.now().isoformat(),
                    'indicators': [event.get('source_ip'), event.get('process_name') or event.get('event_type')],
                    'raw_event': event
                }
                alerts.append(alert)
        return alerts

    def _check_rule(self, rule, event):
        cond = rule.get('condition', {})
        field = cond.get('field')
        operator = cond.get('operator')
        target_val = cond.get('value')
        
        val = str(event.get(field, ''))
        if not val:
            return False
            
        if operator == 'contains':
            return target_val.lower() in val.lower()
        elif operator == 'regex':
            return bool(re.search(target_val, val, re.IGNORECASE))
        elif operator == 'eq':
            return val.lower() == str(target_val).lower()
            
        return False
