#!/bin/bash
echo "🛡️  Starting Enterprise SOC Platform..."

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
fi

mkdir -p logs

# Kill any existing SOC processes
pkill -f "python src/main.py" 2>/dev/null
pkill -f "uvicorn src.api:app" 2>/dev/null
pkill -f "uvicorn src.web_ui:app" 2>/dev/null
pkill -f "generate_realistic_alerts.py" 2>/dev/null
pkill -f "continuous_alerts.py" 2>/dev/null
sleep 2

# 1. Start main platform engine
python src/main.py > logs/platform.log 2>&1 &
MAIN_PID=$!
echo "✅ SOC Core Engine started (PID: $MAIN_PID)"

# 2. Start REST API (Port 8001)
uvicorn src.api:app --host 0.0.0.0 --port 8001 --reload > logs/api.log 2>&1 &
API_PID=$!
echo "✅ API Server started on port 8001 (PID: $API_PID)"

# 3. Start Web UI Dashboard (Port 8002)
uvicorn src.web_ui:app --host 0.0.0.0 --port 8002 --reload > logs/web_ui.log 2>&1 &
WEB_PID=$!
echo "✅ Web UI Dashboard started on port 8002 (PID: $WEB_PID)"

# 4. Start Alert Generator (Continuous threat feed)
python scripts/generate_realistic_alerts.py --continuous > logs/alerts.log 2>&1 &
ALERT_PID=$!
echo "✅ Realistic Threat Feed Generator started (PID: $ALERT_PID)"

sleep 3

LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
if [ -z "$LOCAL_IP" ]; then
    LOCAL_IP="127.0.0.1"
fi

echo ""
echo "=========================================================="
echo "🎯 ENTERPRISE SOC PLATFORM IS NOW RUNNING LOCALLY!"
echo "=========================================================="
echo "   🌐 Web Dashboard: http://localhost:8002"
echo "   🌐 Network Access: http://${LOCAL_IP}:8002"
echo "   📊 API Docs & Health: http://localhost:8001/health"
echo "   📋 Alerts Endpoint: http://localhost:8001/api/alerts"
echo "   🚨 Incidents Endpoint: http://localhost:8001/api/incidents"
echo "   📁 Logs Directory: $SCRIPT_DIR/logs/"
echo "=========================================================="
