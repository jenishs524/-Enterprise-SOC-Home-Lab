import os
import json
import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from fastapi import FastAPI, HTTPException, Header, Depends, Query, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from src.database import Database
from src.telemetry_normalizer import TelemetryNormalizer
from src.alert_rules import AlertRulesEngine
from src.ml_detector import MLAnomalyDetector
from src.risk_engine import RiskEngine
from src.investigations import InvestigationWorkspace
from src.case_management import CaseManager
from src.assets import AssetManager
from src.soc_health import SOCHealthMonitor
from src.threat_intel import ThreatIntel
from src.mitre_coverage import MITRECoverageAnalyzer
from src.playbooks import PlaybookEngine
from src.reports import SOCReportGenerator
from src.security import generate_token, verify_token, hash_password, verify_password
from src.audit import AuditLogger

app = FastAPI(
    title="Enterprise SOC Laboratory REST API",
    description="Modular API engine powering real-time security operations, telemetry ingestion, incident triage, threat hunting, and SOAR playbooks.",
    version="2.5.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Core Instances
db = Database()
normalizer = TelemetryNormalizer()
rules_engine = AlertRulesEngine()
ml_detector = MLAnomalyDetector()
risk_engine = RiskEngine()
investigation_ws = InvestigationWorkspace(db)
case_mgr = CaseManager(db)
asset_mgr = AssetManager(db)
soc_health_mon = SOCHealthMonitor(db)
threat_intel = ThreatIntel()
mitre_analyzer = MITRECoverageAnalyzer()
playbook_engine = PlaybookEngine()
report_gen = SOCReportGenerator(db)
audit_logger = AuditLogger(db)

# Data Schemas
class AlertItem(BaseModel):
    title: str
    severity: str
    description: Optional[str] = ""
    source: Optional[str] = "system"
    destination: Optional[str] = "0.0.0.0"
    indicators: Optional[List[str]] = []
    environment: Optional[str] = "lab"

class IncidentItem(BaseModel):
    title: str
    severity: str
    description: Optional[str] = ""
    alert_id: Optional[str] = ""
    priority: Optional[str] = "P2"
    category: Optional[str] = "Security Incident"

class TelemetryPayload(BaseModel):
    source_type: Optional[str] = "auto"
    raw_event: Dict[str, Any]

class LoginRequest(BaseModel):
    username: str
    password: str

class PlaybookExecRequest(BaseModel):
    playbook_id: str
    target: str
    approved: Optional[bool] = False

# Routes

@app.get("/")
def read_root():
    return {
        "service": "Enterprise SOC Platform API",
        "status": "online",
        "version": "2.5.0",
        "documentation": "/docs"
    }

@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "soc-platform",
        "timestamp": datetime.now().isoformat()
    }

@app.post("/api/auth/login")
def login(req: LoginRequest):
    """
    Authentication endpoint.
    Credentials are checked against the users table (hashed) or the LAB_ADMIN_PASSWORD
    environment variable for the built-in 'admin' account.
    No passwords are accepted from hardcoded source-code values.
    """
    lab_admin_pass = os.getenv("LAB_ADMIN_PASSWORD", "")
    # Check built-in lab admin account via env var
    if req.username == "admin" and lab_admin_pass and req.password == lab_admin_pass:
        token = generate_token("admin", "Administrator")
        audit_logger.log("admin", "Administrator", "LOGIN_SUCCESS", "auth", "admin")
        return {"access_token": token, "token_type": "bearer", "role": "Administrator"}
    # Check database users table
    cursor = db.get_cursor()
    cursor.execute("SELECT password_hash, role FROM users WHERE username = ? AND is_active = 1", (req.username,))
    row = cursor.fetchone()
    if row and verify_password(req.password, row["password_hash"]):
        token = generate_token(req.username, row["role"])
        audit_logger.log(req.username, row["role"], "LOGIN_SUCCESS", "auth", req.username)
        return {"access_token": token, "token_type": "bearer", "role": row["role"]}
    audit_logger.log(req.username, "unknown", "LOGIN_FAILED", "auth", req.username, status="FAILED")
    raise HTTPException(status_code=401, detail="Invalid username or password")

@app.get("/api/stats")
def get_stats():
    stats = db.get_stats()
    stats["uptime"] = "running"
    stats["start_time"] = datetime.now().isoformat()
    return stats

# Telemetry Ingestion
@app.post("/api/v1/telemetry/ingest")
def ingest_telemetry(payload: TelemetryPayload):
    norm = normalizer.normalize(payload.raw_event, payload.source_type)
    
    # Store event
    cursor = db.get_cursor()
    cursor.execute('''
        INSERT INTO events 
        (event_id, timestamp, source_type, source_product, hostname, source_ip, destination_ip,
         source_port, destination_port, username, process_name, event_type, severity, risk_score, raw_event, normalized_event, environment)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        norm["event_id"], norm["timestamp"], norm["source_type"], norm["source_product"],
        norm["hostname"], norm["source_ip"], norm["destination_ip"], norm["source_port"],
        norm["destination_port"], norm["username"], norm["process_name"], norm["event_type"],
        norm["severity"], norm["risk_score"], json.dumps(norm["raw_event"]), json.dumps(norm), norm["environment"]
    ))
    db.conn.commit()

    # Rule evaluation
    triggered_alerts = rules_engine.evaluate_event(norm)
    for alt in triggered_alerts:
        alt_id = f"ALERT-{uuid.uuid4().hex[:8]}"
        alt["id"] = alt_id
        enriched = threat_intel.enrich_alert(alt)
        risk_res = risk_engine.calculate_risk(enriched)
        enriched["risk_score"] = risk_res["risk_score"]
        db.save_alert(enriched)

    return {"status": "success", "event_id": norm["event_id"], "alerts_triggered": len(triggered_alerts)}

# Alerts API
@app.get("/api/alerts")
def get_alerts(limit: int = 100):
    return db.get_alerts(limit=limit)

@app.post("/api/alerts")
def create_alert(alert: AlertItem):
    alert_id = f"ALERT-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:4]}"
    alert_dict = alert.dict()
    alert_dict["id"] = alert_id
    alert_dict["timestamp"] = datetime.now().isoformat()
    
    # ML & Threat Intel Enrichment
    ml_res = ml_detector.detect(alert_dict)
    alert_dict["anomaly_score"] = ml_res["anomaly_score"]
    alert_dict["confidence"] = int(ml_res["confidence"] * 100)
    
    enriched = threat_intel.enrich_alert(alert_dict)
    risk_res = risk_engine.calculate_risk(enriched)
    enriched["risk_score"] = risk_res["risk_score"]

    db.save_alert(enriched)

    # Auto-create incident for critical severity
    if alert.severity.lower() == "critical":
        inc_id = f"INC-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        db.save_incident({
            "id": inc_id,
            "title": f"Incident: {alert.title}",
            "severity": "critical",
            "priority": "P1",
            "status": "open",
            "alert_id": alert_id,
            "description": alert.description,
            "category": "Critical Threat Auto-Escalation"
        })

    return {"status": "success", "alert_id": alert_id, "alert": enriched}

@app.delete("/api/alerts/{alert_id}")
def delete_alert(alert_id: str):
    cursor = db.get_cursor()
    cursor.execute("DELETE FROM alerts WHERE id = ?", (alert_id,))
    db.conn.commit()
    return {"status": "success", "message": f"Alert {alert_id} deleted"}

# Incidents API
@app.get("/api/incidents")
def get_incidents(limit: int = 50):
    return db.get_incidents(limit=limit)

@app.post("/api/incidents")
def create_incident(incident: IncidentItem):
    inc_id = f"INC-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    inc_dict = incident.dict()
    inc_dict["id"] = inc_id
    inc_dict["created_at"] = datetime.now().isoformat()
    inc_dict["status"] = "open"
    db.save_incident(inc_dict)
    return {"status": "success", "incident_id": inc_id}

@app.post("/api/incidents/{incident_id}/resolve")
def resolve_incident(incident_id: str):
    cursor = db.get_cursor()
    now_str = datetime.now().isoformat()
    cursor.execute(
        "UPDATE incidents SET status = 'resolved', resolved_at = ? WHERE id = ?",
        (now_str, incident_id)
    )
    db.conn.commit()
    return {"status": "success", "message": f"Incident {incident_id} marked as resolved"}

# Case Management
@app.get("/api/cases")
def list_cases():
    return case_mgr.list_cases()

# Investigation Workspace
@app.get("/api/investigation/graph")
def get_entity_graph():
    return investigation_ws.get_entity_graph()

@app.get("/api/investigation/timeline")
def get_timeline():
    return investigation_ws.get_timeline()

# Threat Hunting
@app.get("/api/hunting/events")
def hunt_events(q: str = Query("", description="Search term")):
    cursor = db.get_cursor()
    if q:
        search_pattern = f"%{q}%"
        cursor.execute('''
            SELECT * FROM events 
            WHERE source_ip LIKE ? OR destination_ip LIKE ? OR username LIKE ? OR hostname LIKE ? OR event_type LIKE ? OR process_name LIKE ?
            ORDER BY timestamp DESC LIMIT 100
        ''', (search_pattern, search_pattern, search_pattern, search_pattern, search_pattern, search_pattern))
    else:
        cursor.execute("SELECT * FROM events ORDER BY timestamp DESC LIMIT 100")
    
    rows = cursor.fetchall()
    return [dict(r) for r in rows]

# Assets API
@app.get("/api/assets")
def get_assets():
    return asset_mgr.get_assets()

# MITRE Coverage API
@app.get("/api/mitre/coverage")
def get_mitre_coverage():
    return mitre_analyzer.get_coverage_matrix()

# Threat Intelligence Check
@app.get("/api/threat_intel/check")
def check_threat_intel(indicator: str):
    return threat_intel.check_ip(indicator)

# Playbooks API
@app.get("/api/playbooks")
def get_playbooks():
    return playbook_engine.get_playbooks()

@app.post("/api/playbooks/execute")
def execute_playbook(req: PlaybookExecRequest):
    return playbook_engine.execute_playbook(req.playbook_id, req.target, approved=req.approved)

# SOC Health API
@app.get("/api/soc/health")
def get_soc_health():
    return soc_health_mon.get_system_health()

# Reports API
@app.get("/api/reports/download")
def download_report(fmt: str = "json", report_type: str = "daily_soc"):
    if fmt == "csv":
        return report_gen.generate_csv_report(report_type)
    return report_gen.generate_json_report(report_type)
